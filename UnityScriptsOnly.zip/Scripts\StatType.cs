// StatType.cs
using UnityEngine;

public enum StatType
{
    HP,
    Sanity,
    Hunger,
    Thirst,
    Fatigue,
    Hope,
    // 需要就往下加：Obedience, Reputation, Radiation, Infection, AugmentationLoad, Trust, Control ...
}
