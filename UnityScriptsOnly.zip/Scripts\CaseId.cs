// CaseId.cs — 只保留 None；其餘請自行在下方區塊新增。
public enum CaseId
{
    None,
    hospital,
    // === 你可以從這裡開始自行添加 ===
    // 例：
    // TownSquare,
    // DarkAlley,
    // Inn,
    // ===================================
}
